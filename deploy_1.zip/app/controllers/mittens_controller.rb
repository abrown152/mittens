class MittensController < ApplicationController
end
